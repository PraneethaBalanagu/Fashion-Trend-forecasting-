class Config:
    SQLALCHEMY_DATABASE_URI = 'mssql+pyodbc://@DESKTOP-DI486IP/trend?driver=ODBC+Driver+17+for+SQL+Server'

    SQLALCHEMY_TRACK_MODIFICATIONS = False
